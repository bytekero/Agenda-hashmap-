/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATA;

/**
 *
 * @author anton
 */
public class Persona {
    private String nombre;
    private String telefono;
    private String dni;

    public Persona(String nombre, String telefono, String dni) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.dni = dni;
        if (!dni.matches("\\d{8}[A-Z]")) {
            throw new IllegalArgumentException("Error: El DNI debe tener 8 numeros y 1 letra.");
        }
        
        
        if (!telefono.matches("\\d{9}")) {
            throw new IllegalArgumentException("Error: El telefono debe tener exactamente 9 numeros.");
        }
        
        
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", telefono=" + telefono + ", DNI=" + dni + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getDni() {
        return dni;
    }
    
    
}
