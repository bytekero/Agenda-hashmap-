/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package DATA;

import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author anton
 */
public class Miapp extends Thread{

  
    private static Agenda agenda = new Agenda();
    private static Scanner scanner = new Scanner(System.in);
    String nombre;
   

    public Miapp(String nombre) {
        this.nombre = nombre;
    }
    
    

    @Override
    public void run() {
       super.run(); 
       creardatosprueba();
       boolean res=true;
       
       while(res){
           mostrarMenu();
           Scanner escanear = new Scanner(System.in);
           int respuesta = escanear.nextInt();
           switch(respuesta){
               case 1:
                   agregarPerona();
                   break;
                   
               case 2:
                   buscarPersona();
                   break;
               case 3:
                   eliminarPersona();
                   break;
               case 4:
                   mostrarPersona();
                   break;
               case 5:
                   System.out.println("Hasta pronto");
                   res=false;
                   break;
               default:
                   System.out.println("Opcion no valida. Intentalo de nuevo.");
             
           } 
       
       
       }
    }
    
    public static void main(String[] args) {
       new Miapp("Agenda").start();
       
    }
    
    private static void creardatosprueba(){
        Persona p1=new Persona("Antonio","685654545","06578560C");
    
    
    } 
    private static void mostrarMenu() {
       
        System.out.println("\n--- MENU DE LA AGENDA ---");
        System.out.println("1. Agregar persona"); 
        System.out.println("2. Buscar persona");  
        System.out.println("3. Eliminar persona"); 
        System.out.println("4. Mostrar todas las personas"); 
        System.out.println("5. Salir");
        System.out.print("Elige una opcion:");
        
        
    }
   
    private static void agregarPerona(){
        Scanner escanear = new Scanner(System.in);
        System.out.println("Introduce tu nombre");
        String nombre = escanear.nextLine();
        System.out.println("Introduce tu telefono");
        String telefono = escanear.nextLine();
        System.out.println("Introduce tu DNI");
        String dni = escanear.nextLine();
        if (agenda.agregar(dni,nombre,telefono)) {
                System.out.println("Persona añadida correctamente");
            } else {
                System.out.println("Error: Ya existe una persona con ese DNI");
            }
        
        
    }

    private static void buscarPersona() {
        System.out.print("Introduce el DNI de la persona a buscar: ");
        String dni = scanner.nextLine();
        Persona encontrada = agenda.buscar(dni);

        if (encontrada != null) {
            System.out.println("Persona encontrada: " + encontrada);
        } else {
            System.out.println("No se encontro ninguna persona con ese DNI.");
        }
    }

    private static void eliminarPersona() {
        
        System.out.print("Introduce el DNI de la persona a eliminar: ");
        String dni = scanner.nextLine();

        if (agenda.eliminar(dni)) {
            System.out.println("Persona eliminada correctamente.");
        } else {
            System.out.println("No se encontro ninguna persona con ese DNI.");
        }
    }

    private static void mostrarPersona() {
        agenda.mostrarTodas();
    }
    
}
