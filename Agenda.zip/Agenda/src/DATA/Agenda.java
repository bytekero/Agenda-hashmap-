/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DATA;

import java.util.HashMap;

/**
 *
 * @author anton
 */
public class Agenda {
    HashMap <String, Persona> lista;

    public Agenda() {
        this.lista = new HashMap<>();
    }

    
    public boolean agregar(String dni, String nombre, String telefono){
       Persona persona =new Persona(nombre,telefono,dni);
       if (lista.containsKey(persona.getDni())) {
            return false; 
        }
        lista.put(persona.getDni(), persona);
        return true;
    
    
    }
    public Persona buscar(String dni) {
        return lista.get(dni.toUpperCase());
    }

   
    public boolean eliminar(String dni) {
        
        if (lista.containsKey(dni.toUpperCase())) {
            lista.remove(dni.toUpperCase());
            return true;
        }
        return false;
    }

    
    public void mostrarTodas() {
        if (lista.isEmpty()) {
            System.out.println("La agenda esta vacia.");
            return;
        }
        System.out.println("\n--- LISTA DE CONTACTOS ---");
        for (Persona p : lista.values()) {
            System.out.println(p); 
        }
       
    }
    
}
